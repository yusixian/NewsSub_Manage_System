package kernel.dao;

public interface User {
    public String showUserName();
    public String showPassWord();
    public String showType();
}
