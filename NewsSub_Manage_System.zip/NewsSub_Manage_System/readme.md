需要：装好java8、mysql

将kernal-utils-Dbutil中的URL、USER、PASSWORD更换为自己的数据库

然后执行kernal-dbs中的newSystem.sql脚本进行数据库的初始化！

运行即可

注意：数据库的驱动包在项目的libs目录下,务必将驱动包添加到项目依赖中

